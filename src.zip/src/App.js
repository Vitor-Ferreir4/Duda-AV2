import Navbar from './componentes/Navbar';
import Home from './componentes/home';
import Senai from './componentes/senai';
import Footer from './componentes/footer';
import './App.css';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <Navbar />
        <Senai />
        <Home />
        <Footer />
      </header>
    </div>
  );
}

export default App;
