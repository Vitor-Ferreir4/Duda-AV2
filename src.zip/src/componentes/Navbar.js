import './Navbar.css'

function Navbar(){
    return(
        <nav className="nemezes">
                <ul className="nemezes-nav">
                    <li className="nemezes-nav-item">
                        <a className="nemezes-nav-link" href="/"><h4>Home</h4></a>
                    </li>
                    <li className="nemezes-nav-item">
                        <a className="nemezes-nav-link" href="/quem"><h4>Quem Somos?</h4></a>
                    </li>
                    <li className="nemezes-nav-item">
                        <a className="nemezes-nav-link" href="/contato"><h4>Contato</h4></a>
                    </li>
                </ul>
        </nav>
    )
}

export default Navbar;