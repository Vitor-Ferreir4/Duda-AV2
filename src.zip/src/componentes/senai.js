import '../App.css'

function Senai(){
    return(
        <img className='senai' src={require('../assets/SENAI.png')} width={130}/>
    )
}

export default Senai