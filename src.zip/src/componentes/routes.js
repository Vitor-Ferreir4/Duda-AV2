import React from "react";
import { Route, BrowserRouter } from "react-router-dom";
import Home from "./Home";
import Quem from "./Quem-somos";
import Usuario from "./Usuario";

const Routes = () => {
   return(
       <BrowserRouter>
           <Route component = { Home }  path="/" exact />
           <Route component = { Quem }  path="/quem" />
       </BrowserRouter>
   )
}

export default Routes;